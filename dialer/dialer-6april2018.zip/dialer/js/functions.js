
webphone_api.onLoaded(function ()
        {
           
            webphone_api.setparameter('serveraddress', 'ace.metrocentrex.net'); // yoursipdomain.com your VoIP server IP address or domain name
            webphone_api.setparameter('username', extension);      // SIP account username
            webphone_api.setparameter('password', 'Metro!100');      // SIP account password (see the "Parameters encryption" in the documentation)
                  //webphone_api.start();
                 
        });