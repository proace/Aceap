<?php
$host = "localhost";
$name = "acesystem";
$user = "root";
$password = "";
$pdo = "";

try
{
    $pdo = new PDO("mysql:host=$host;dbname=$name", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
  //echo $e->getMessage();
}
  
?>
